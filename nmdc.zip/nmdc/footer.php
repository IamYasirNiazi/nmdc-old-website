<?php
include_once "enroll.php";
?>
<style>
.modal .modal-content .close {
    position: absolute;
    top: -7px;
    right: 10px;
    z-index: 100;
    font-size: 46px;
}
</style>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						
                        <div class="col-md-12 modal_body_left modal_body_left1">
<h3 class="agileinfo_sign"><span></span></h3>
<!--
<a href="admission/" target="_blank">
<button class="btn btn-success" style="margin-bottom:20px;">Apply Online Admission 2022-2023</button>
</a>
-->
<img src="img/01bb.webp" alt="Main Banner" style="width:100%;">
						</div>

						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal -->

<!-- Modal1 -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						
                        <div class="col-md-12 modal_body_left modal_body_left1">
<!--<h3 class="agileinfo_sign"><span></span></h3>-->
<img src="img/img_sm_4.webp" alt="Admissions are Open" style="width:100%;">
						</div>

						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal1 -->

<!-- Modal2 -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						
                        <div class="col-md-12 modal_body_left modal_body_left1">
<!--<h3 class="agileinfo_sign"><span></span></h3>-->
<img src="img/bb.webp" alt="Admissions are Open" style="width:100%;">
						</div>

						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal2 -->

<!-- Modal3 -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						
                        <div class="col-md-12 modal_body_left modal_body_left1">
<!--<h3 class="agileinfo_sign"><span></span></h3>-->
<img src="img/img_sm_43.webp" alt="Admissions are Open" style="width:100%;">
						</div>

						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal3 -->

<!-- Modal4 -->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
						<div class="modal-body modal-body-sub_agile">
						
                        <div class="col-md-12 modal_body_left modal_body_left1">
<!--<h3 class="agileinfo_sign"><span></span></h3>-->
<img src="img/img_sm_44.webp" alt="Admissions are Open" style="width:100%;">
						</div>

						<div class="clearfix"></div>
					</div>
				</div>
				<!-- //Modal content-->
			</div>
		</div>
<!-- //Modal4 -->

      
<footer class="probootstrap-footer probootstrap-bg">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <div class="probootstrap-footer-widget">
                <h3>About NMDC</h3>
                <p>Niazi Medical & Dental College, Sargodha and attached Niazi Welfare Foundation Teaching Hospital are located on Lahore Road, 10 km away from Sargodha city. The complex is owned by M/S Niazi Medical & Dental College (Private) Ltd.</p>
                <h3>Social</h3>
                <ul class="probootstrap-footer-social">
<li><a href="https://twitter.com/NMDC12" target="_blank"><i class="icon-twitter"></i></a></li>
<li><a href="https://www.facebook.com/NiaziMDC" target="_blank"><i class="icon-facebook"></i></a></li>
<li><a href="https://www.instagram.com/nmdcsgd2019" target="_blank"><i class="icon-instagram"></i></a></li>
<li><a href="https://youtu.be/E-RvUE-co3c"><i class="icon-youtube"></i></a></li>
                </ul>
              </div>
            </div>
            <div class="col-md-3 col-md-push-1">
              <div class="probootstrap-footer-widget">
                <h3>Links</h3>
                <ul>
                  <li><a href="index.php">Home</a></li>
                  <li><a href="index.php#about">About Us</a></li>
                  <li><a href="index.php#Events">Events</a></li>
                  <li><a href="index.php#Courses">Courses</a></li>
                  <li><a href="contact-us.php">Contact</a></li>
                  <li><a href="merit-lists.php">Merit Lists</a></li>
                </ul>
              </div>
            </div>
            <div class="col-md-4">
              <div class="probootstrap-footer-widget">
                <h3>Contact Info</h3>
                <ul class="probootstrap-contact-info">
                  <li><i class="icon-location2"></i> <span>10,km Lahore Road Sargodha</span></li>
                  <li><i class="icon-mail"></i><span>info@nmdc.edu.pk, bilal@nmdc.edu.pk</span></li>
                  <li><i class="icon-phone2"></i><span>For MBBS +923-111-248-248, +92-301-124-8248</span></li>
                  <li><i class="icon-phone2"></i><span>For DPT +923-088-248248</span></li>
                  <li><i class="icon-phone2"></i><span>For Doctor of Pharmacy +923-071-248-248</span></li>
                                                    </ul>
              </div>
            </div>
           
          </div>
          <!-- END row -->
          
        </div>

        <div class="probootstrap-copyright">
          <div class="container">
            <div class="row">
              <div class="col-md-8 text-left">
            
				  <p>&copy; 2018-<?php echo date('Y'); ?> <a href="http://www.nmdc.edu.pk/">NIAZI MEDICAL AND DENTAL COLLEGE</a>. All Rights Reserved. <br>Designed &amp; Developed by <a href="http://www.nmdc.edu.pk" target="_blank">Sarosh Khan (92)324-7301987</a>
                


				<!--
                <i class="icon icon-heart"></i>
                -->
 <!-- & <a href="http://www.switch2itech.com/" target="_blank">Switch2Itech</a></p>
              </div>
              <div class="col-md-4 probootstrap-back-to-top">
                <p><a href="#" class="js-backtotop">Back to top <i class="icon-arrow-long-up"></i></a></p>
              </div>
            </div>
          </div>
        </div>
      </footer>

    </div>
    <!-- END wrapper -->
    

    <script src="js/scripts.min.js"></script>
    <script src="js/main.min.js"></script>
    <script src="js/custom.js"></script>
    
    <script type="text/javascript">
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
  </body>
</html>