<?php
include_once "COPlinks.php";
include_once "COPheaderb.php";
include_once "COPprogram.php";
include_once "COPfooterb.php";
?>