<?php
include_once "links.php";
include_once "header.php";
include_once "banner.php";
include_once "about.php";
include_once "events.php";
include_once "courses.php";
include_once "hospitals.php";
include_once "testimonials.php";
include_once "whynmc.php";
include_once "footer.php";
?>